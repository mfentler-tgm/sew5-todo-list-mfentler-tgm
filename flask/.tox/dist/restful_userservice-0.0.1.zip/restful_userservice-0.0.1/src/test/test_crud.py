
def test_simple():
    assert 1 == 2